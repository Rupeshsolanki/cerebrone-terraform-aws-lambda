def helloFromRupesh(events,context):
    print("New Cerebrone Task assign")